const { ContextMenuCommandBuilder, ApplicationCommandType, ModalBuilder, TextInputBuilder, ActionRowBuilder, TextInputStyle, ChannelType, 
    EmbedBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new ContextMenuCommandBuilder()
    .setName('Dashboard1')
    .setType(ApplicationCommandType.Message),
    async execute(interaction){
        const modal = new ModalBuilder()
        .setTitle(`Push-up calculator`)
        .setCustomId('pushupmodal')

        const month = new TextInputBuilder()
        .setCustomId('month')
        .setRequired(true)
        .setPlaceholder('')
        .setLabel('The current Month of the Year')
        .setStyle(TextInputStyle.Short);

        const day = new TextInputBuilder()
        .setCustomId('day')
        .setRequired(true)
        .setPlaceholder('')
        .setLabel('The current Day of the Month')
        .setStyle(TextInputStyle.Short);

        const one = new ActionRowBuilder().addComponents(day);
        const two = new ActionRowBuilder().addComponents(month);

        modal.addComponents(one, two);
        await interaction.showModal(modal);
    }
}