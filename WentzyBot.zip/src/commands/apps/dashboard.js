const { ContextMenuCommandBuilder, ApplicationCommandType, ModalBuilder, TextInputBuilder, ActionRowBuilder, TextInputStyle, ChannelType, 
    EmbedBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, Collector, Collection, ComponentType } = require('discord.js');

module.exports = {
    data: new ContextMenuCommandBuilder()
    .setName('Counter Dashboard')
    .setType(ApplicationCommandType.Message),
    async execute(interaction){

        const embed = new EmbedBuilder()
        .setTitle('Push-up Counter Dashboard')
        .setDescription(`> Please select the month below`)
        .setColor('000000')
        .setTimestamp()
        .setFooter({ text: `Created by freewentzy | ${interaction.guild.name}`, iconURL: `${interaction.guild.iconURL()}`});

        const row1 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setCustomId('jan')
            .setLabel('January')
            .setStyle(ButtonStyle.Primary),

            new ButtonBuilder()
            .setCustomId('feb')
            .setLabel(`February`)
            .setStyle(ButtonStyle.Primary),

            new ButtonBuilder()
            .setCustomId('mar')
            .setLabel('March')
            .setStyle(ButtonStyle.Primary),
        );

        const row2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setCustomId('apr')
            .setLabel('April')
            .setStyle(ButtonStyle.Primary),

            new ButtonBuilder()
            .setCustomId('may')
            .setLabel(`May`)
            .setStyle(ButtonStyle.Primary),

            new ButtonBuilder()
            .setCustomId('jun')
            .setLabel('June')
            .setStyle(ButtonStyle.Primary),
        );

        const row3 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setCustomId('jul')
            .setLabel('July')
            .setStyle(ButtonStyle.Primary),

            new ButtonBuilder()
            .setCustomId('aug')
            .setLabel(`August`)
            .setStyle(ButtonStyle.Primary),

            new ButtonBuilder()
            .setCustomId('sep')
            .setLabel('September')
            .setStyle(ButtonStyle.Primary),
        );

        const row4 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setCustomId('oct')
            .setLabel('October')
            .setStyle(ButtonStyle.Primary),

            new ButtonBuilder()
            .setCustomId('nov')
            .setLabel(`November`)
            .setStyle(ButtonStyle.Primary),

            new ButtonBuilder()
            .setCustomId('dec')
            .setLabel('December')
            .setStyle(ButtonStyle.Primary),
        );

        

        await interaction.reply({ embeds: [embed], components: [row1, row2, row3, row4], ephemeral: false });
    }
}