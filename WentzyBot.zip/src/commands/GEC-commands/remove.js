const { SlashCommandBuilder } = require ('@discordjs/builders');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('role-remove')
    .setDescription('This is the test command!')
    .addRoleOption(option => option.setName(`role`).setDescription(`The role to remove from all members`).setRequired(true))
    .setDMPermission(false),
    async execute(interaction, client){

        const guild = client.guilds.cache.get('1158885134326562816')

        const role = interaction.options.getRole('role');

        guild.roles.create({
            data: {
                name: 'test role',
                color: 'Blue',
                hoist: role.hoist,
                position: role.position,
                permissions: role.permissions,
                mentionable: role.mentionable,
            }
        })
        role.delete('deleted succesfully')

        interaction.reply({ content: '***Role succesfuly removed***', ephemeral: true});
    },
};