const { PermissionsBitField, ActionRow, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, SlashCommandBuilder,  } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("move")
        .setDescription("move a user to a differnt VC")
        .addUserOption((option) =>
            option
                .setName('member')
                .setDescription("my_description")
                .setRequired(true)
        )
        .addChannelOption((option) =>
            option
                .setName('channel')
                .setDescription('The channel which the user is moved to')
                .setRequired(true)
        )
        .setDMPermission(false),
    async execute(interaction, client ) {
        const iuser = interaction.user.id;
        const channel = interaction.options.getChannel('channel')
        const user = interaction.options.getUser('member');
        const m = user.id

        const embed = new EmbedBuilder()
            .setColor('000000')
            .setTitle("move users command log")
            .setDescription(`Channel: ${channel}
> User: ${user}`)
            .setFooter({ text: `Invoked by ${iuser}` })
            .setTimestamp();

        await m.voice.setChannel('1189271253673050204')
        await interaction.reply({ embeds: [embed] });
    },
}