const { SlashCommandBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('user-debt')
        .setDescription('Use this command to find a user\'s balance or add to their debt')
        .setDMPermission(false),
    async execute(interaction) {
        try {
            // Defer the reply initially
            await interaction.deferReply({ ephemeral: true });

            // Fetch guild members with a timeout
            const members = await interaction.guild.members.fetch({ timeout: 10000 }); // Adjust timeout as needed

            // Create select menu options
            const options = members.map(member => ({
                label: member.user.tag,
                value: member.id,
                description: `Select ${member.user.tag}`,
            }));

            // Create a select menu with the options
            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId('selectUser')
                .setPlaceholder('Select a user')
                .addOptions(options);

            // Create an action row containing the select menu
            const actionRow = new ActionRowBuilder()
                .addComponents(selectMenu);

            // Edit the deferred reply with the select menu
            await interaction.followUp({
                content: 'Select a user:',
                components: [actionRow]
            });
        } catch (error) {
            console.error('Error creating select menu:', error);
            if (error instanceof DiscordAPIError && error.code === 10007) {
                // Inform the user about the timeout error
                await interaction.followUp({ content: 'Sorry, I couldn\'t fetch the guild members in time. Please try again later.', ephemeral: true });
            } else {
                // Handle other errors
                await interaction.followUp({ content: 'An error occurred.', ephemeral: true });
            }
        }
    }
};