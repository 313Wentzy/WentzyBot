const { ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, TextInputBuilder, ActionRowBuilder, TextInputStyle, ChannelType, 
    EmbedBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField } = require("discord.js");

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        
        if (interaction.customId == 'pushupmodal') {
            const month = interaction.fields.getTextInputValue('month');
            const day = interaction.fields.getTextInputValue('month');

            

        await interaction.reply({ content: `${month}/${day}/24`  }); //embeds: [embed], components: [row]
        } 
    }
}