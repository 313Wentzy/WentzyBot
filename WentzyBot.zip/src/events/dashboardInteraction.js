const { ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, TextInputBuilder, ActionRowBuilder, TextInputStyle, ChannelType, 
    EmbedBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField, embedLength } = require("discord.js");
const Canvas = require('@napi-rs/canvas');
const math = require('mathjs');



module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        
        if (interaction.customId == 'jan') {
            const janmodal = new ModalBuilder()
        .setTitle(`Push-up calculator`)
        .setCustomId('janmodal')

        const day = new TextInputBuilder()
        .setCustomId('day')
        .setRequired(true)
        .setPlaceholder('Ex: 1, 5, 15. . . ')
        .setLabel('The current Day of the Month')
        .setStyle(TextInputStyle.Short);

        const one = new ActionRowBuilder().addComponents(day);

        janmodal.addComponents(one);
        await interaction.showModal(janmodal);
        } else if (interaction.customId == 'janmodal') {
            const day = interaction.fields.getTextInputValue('day');            

            const n = day
            const sd = Math.floor(n * 86400); // sd = selected date in seconds
            const fulldate = Math.floor(1703998800 + sd);

            const nn = Math.floor(parseInt(n) + 1)
            const m = Math.floor(parseInt(n) * parseInt(nn) )
            const tamount = Math.floor(parseInt(m) / 2)
            const tamountminus = Math.floor(parseInt(tamount)-parseInt(n))

            const percent = Math.round(parseInt(day)/366 * 100)

            const daysremain = Math.round(366-parseInt(day))


            const janembed = new EmbedBuilder()
            .setTitle(`Push-ups for <t:${fulldate}:D>`)
            .addFields(
                { name: 'Push-ups required for the day:', value: `**${n}**`, inline: true },
                { name: 'Total Push-ups done before today:', value: `**${tamountminus}**`, inline: true },
                { name: 'Total Push-ups done after today:', value: `**${tamount}**`, inline: true },
                )
            .setDescription(`> Today is **${percent}%** through the entire year

*Today is the day **${day}** of the year and **${daysremain}** remain*

**Stats:**`)
            .setFooter({ text: `Created by freewentzy | ${interaction.guild.name}`, iconURL: `${interaction.guild.iconURL()}`});

            await interaction.reply({ embeds: [janembed]})


        } else if (interaction.customId == 'feb') {
            const febmodal = new ModalBuilder()
        .setTitle(`Push-up calculator`)
        .setCustomId('febmodal')

        const febday = new TextInputBuilder()
        .setCustomId('day')
        .setRequired(true)
        .setPlaceholder('Ex: 1, 5, 15. . . ')
        .setLabel('The current Day of the Month')
        .setStyle(TextInputStyle.Short);

        const one = new ActionRowBuilder().addComponents(febday);

        febmodal.addComponents(one);
        await interaction.showModal(febmodal);
        } else if (interaction.customId == 'febmodal') {
            const febday = interaction.fields.getTextInputValue('day');            

            const n = Math.floor(parseInt(febday) + 31)
            const sd = Math.floor(n * 86400); // sd = selected date in seconds
            const fulldate = Math.floor(1703998800 + sd);

            const nn = Math.floor(parseInt(n) + 1)
            const m = Math.floor(parseInt(n) * parseInt(nn) )
            const tamount = Math.floor(parseInt(m) / 2)
            const tamountminus = Math.floor(parseInt(tamount)-parseInt(n))

            const percent = Math.round(parseInt(n)/366 * 100)



            const daysremain = Math.round(366-parseInt(n))


            const febembed = new EmbedBuilder()
            .setTitle(`Push-ups for <t:${fulldate}:D>`)
            .addFields(
                { name: 'Push-ups required for the day:', value: `**${n}**`, inline: true },
                { name: 'Total Push-ups done before today:', value: `**${tamountminus}**`, inline: true },
                { name: 'Total Push-ups done after today:', value: `**${tamount}**`, inline: true },
                )
            .setDescription(`> Today is **${percent}%** through the entire year

*Today is the day **${n}** of the year and **${daysremain}** remain*

**Stats:**`)
            .setFooter({ text: `Created by freewentzy | ${interaction.guild.name}`, iconURL: `${interaction.guild.iconURL()}`});

            await interaction.reply({ embeds: [febembed]})
        } else if  (interaction.customId == 'mar') {
            const marmodal = new ModalBuilder()
        .setTitle(`Push-up calculator`)
        .setCustomId('marmodal')

        const marday = new TextInputBuilder()
        .setCustomId('day')
        .setRequired(true)
        .setPlaceholder('Ex: 1, 5, 15. . . ')
        .setLabel('The current Day of the Month')
        .setStyle(TextInputStyle.Short);

        const one = new ActionRowBuilder().addComponents(marday);

        marmodal.addComponents(one);
        await interaction.showModal(marmodal);
        } else if (interaction.customId == 'marmodal') {
            const marday = interaction.fields.getTextInputValue('day');            

            const n = Math.floor(parseInt(marday) + 60)
            const sd = Math.floor(n * 86400); // sd = selected date in seconds
            const fulldate = Math.floor(1703998800 + sd);

            const nn = Math.floor(parseInt(n) + 1)
            const m = Math.floor(parseInt(n) * parseInt(nn) )
            const tamount = Math.floor(parseInt(m) / 2)
            const tamountminus = Math.floor(parseInt(tamount)-parseInt(n))

            const percent = Math.round(parseInt(n)/366 * 100)

            const daysremain = Math.round(366-parseInt(n))

            const marembed = new EmbedBuilder()
            .setTitle(`Push-ups for <t:${fulldate}:D>`)
            .addFields(
                { name: 'Push-ups required for the day:', value: `**${n}**`, inline: true },
                { name: 'Total Push-ups done before today:', value: `**${tamountminus}**`, inline: true },
                { name: 'Total Push-ups done after today:', value: `**${tamount}**`, inline: true },
                )
            .setDescription(`> Today is **${percent}%** through the entire year

*Today is the day **${n}** of the year and **${daysremain}** remain*

**Stats:**`)
            .setFooter({ text: `Created by freewentzy | ${interaction.guild.name}`, iconURL: `${interaction.guild.iconURL()}`});

            await interaction.reply({ embeds: [marembed]})
        } else if  (interaction.customId == 'apr') {
            const aprmodal = new ModalBuilder()
        .setTitle(`Push-up calculator`)
        .setCustomId('aprmodal')

        const aprday = new TextInputBuilder()
        .setCustomId('day')
        .setRequired(true)
        .setPlaceholder('Ex: 1, 5, 15. . . ')
        .setLabel('The current Day of the Month')
        .setStyle(TextInputStyle.Short);

        const one = new ActionRowBuilder().addComponents(aprday);

        aprmodal.addComponents(one);
        await interaction.showModal(aprmodal);
        } else if (interaction.customId == 'aprmodal') {
            const aprday = interaction.fields.getTextInputValue('day');            

            const n = Math.floor(parseInt(aprday) + 91)
            const sd = Math.floor(n * 86400); // sd = selected date in seconds
            const fulldate = Math.floor(1703998800 + sd);

            const nn = Math.floor(parseInt(n) + 1)
            const m = Math.floor(parseInt(n) * parseInt(nn) )
            const tamount = Math.floor(parseInt(m) / 2)
            const tamountminus = Math.floor(parseInt(tamount)-parseInt(n))

            const percent = Math.round(parseInt(n)/366 * 100)

            const daysremain = Math.round(366-parseInt(n))

            const aprembed = new EmbedBuilder()
            .setTitle(`Push-ups for <t:${fulldate}:D>`)
            .addFields(
                { name: 'Push-ups required for the day:', value: `**${n}**`, inline: true },
                { name: 'Total Push-ups done before today:', value: `**${tamountminus}**`, inline: true },
                { name: 'Total Push-ups done after today:', value: `**${tamount}**`, inline: true },
                )
            .setDescription(`> Today is **${percent}%** through the entire year

*Today is the day **${n}** of the year and **${daysremain}** remain*

**Stats:**`)
            .setFooter({ text: `Created by freewentzy | ${interaction.guild.name}`, iconURL: `${interaction.guild.iconURL()}`});

            await interaction.reply({ embeds: [aprembed]})
        } else if  (interaction.customId == 'may') {
            const maymodal = new ModalBuilder()
        .setTitle(`Push-up calculator`)
        .setCustomId('maymodal')

        const mayday = new TextInputBuilder()
        .setCustomId('day')
        .setRequired(true)
        .setPlaceholder('Ex: 1, 5, 15. . . ')
        .setLabel('The current Day of the Month')
        .setStyle(TextInputStyle.Short);

        const one = new ActionRowBuilder().addComponents(mayday);

        maymodal.addComponents(one);
        await interaction.showModal(maymodal);
        } else if (interaction.customId == 'maymodal') {
            const mayday = interaction.fields.getTextInputValue('day');            

            const n = Math.floor(parseInt(mayday) + 121)
            const sd = Math.floor(n * 86400); // sd = selected date in seconds
            const fulldate = Math.floor(1703998800 + sd);

            const nn = Math.floor(parseInt(n) + 1)
            const m = Math.floor(parseInt(n) * parseInt(nn) )
            const tamount = Math.floor(parseInt(m) / 2)
            const tamountminus = Math.floor(parseInt(tamount)-parseInt(n))

            const percent = Math.round(parseInt(n)/366 * 100)

            const daysremain = Math.round(366-parseInt(n))

            const mayembed = new EmbedBuilder()
            .setTitle(`Push-ups for <t:${fulldate}:D>`)
            .addFields(
                { name: 'Push-ups required for the day:', value: `**${n}**`, inline: true },
                { name: 'Total Push-ups done before today:', value: `**${tamountminus}**`, inline: true },
                { name: 'Total Push-ups done after today:', value: `**${tamount}**`, inline: true },
                )
            .setDescription(`> Today is **${percent}%** through the entire year

*Today is the day **${n}** of the year and **${daysremain}** remain*

**Stats:**`)
            .setFooter({ text: `Created by freewentzy | ${interaction.guild.name}`, iconURL: `${interaction.guild.iconURL()}`});

            await interaction.reply({ embeds: [mayembed]})
        } else if  (interaction.customId == 'jun') {
            const junmodal = new ModalBuilder()
        .setTitle(`Push-up calculator`)
        .setCustomId('junmodal')

        const junday = new TextInputBuilder()
        .setCustomId('day')
        .setRequired(true)
        .setPlaceholder('Ex: 1, 5, 15. . . ')
        .setLabel('The current Day of the Month')
        .setStyle(TextInputStyle.Short);

        const one = new ActionRowBuilder().addComponents(junday);

        junmodal.addComponents(one);
        await interaction.showModal(junmodal);
        } else if (interaction.customId == 'junmodal') {
            const junday = interaction.fields.getTextInputValue('day');            

            const n = Math.floor(parseInt(junday) + 152)
            const sd = Math.floor(n * 86400); // sd = selected date in seconds
            const fulldate = Math.floor(1703998800 + sd);

            const nn = Math.floor(parseInt(n) + 1)
            const m = Math.floor(parseInt(n) * parseInt(nn) )
            const tamount = Math.floor(parseInt(m) / 2)
            const tamountminus = Math.floor(parseInt(tamount)-parseInt(n))

            const percent = Math.round(parseInt(n)/366 * 100)

            const daysremain = Math.round(366-parseInt(n))

            const junembed = new EmbedBuilder()
            .setTitle(`Push-ups for <t:${fulldate}:D>`)
            .addFields(
                { name: 'Push-ups required for the day:', value: `**${n}**`, inline: true },
                { name: 'Total Push-ups done before today:', value: `**${tamountminus}**`, inline: true },
                { name: 'Total Push-ups done after today:', value: `**${tamount}**`, inline: true },
                )
            .setDescription(`> Today is **${percent}%** through the entire year

*Today is the day **${n}** of the year and **${daysremain}** remain*

**Stats:**`)
            .setFooter({ text: `Created by freewentzy | ${interaction.guild.name}`, iconURL: `${interaction.guild.iconURL()}`});

            await interaction.reply({ embeds: [junembed]})
        } else if  (interaction.customId == 'jul') {
            const julmodal = new ModalBuilder()
        .setTitle(`Push-up calculator`)
        .setCustomId('julmodal')

        const julday = new TextInputBuilder()
        .setCustomId('day')
        .setRequired(true)
        .setPlaceholder('Ex: 1, 5, 15. . . ')
        .setLabel('The current Day of the Month')
        .setStyle(TextInputStyle.Short);

        const one = new ActionRowBuilder().addComponents(julday);

        julmodal.addComponents(one);
        await interaction.showModal(julmodal);
        } else if (interaction.customId == 'julmodal') {
            const julday = interaction.fields.getTextInputValue('day');            

            const n = Math.floor(parseInt(julday) + 182)
            const sd = Math.floor(n * 86400); // sd = selected date in seconds
            const fulldate = Math.floor(1703998800 + sd);

            const nn = Math.floor(parseInt(n) + 1)
            const m = Math.floor(parseInt(n) * parseInt(nn) )
            const tamount = Math.floor(parseInt(m) / 2)
            const tamountminus = Math.floor(parseInt(tamount)-parseInt(n))

            const percent = Math.round(parseInt(n)/366 * 100)

            const daysremain = Math.round(366-parseInt(n))

            const julembed = new EmbedBuilder()
            .setTitle(`Push-ups for <t:${fulldate}:D>`)
            .addFields(
                { name: 'Push-ups required for the day:', value: `**${n}**`, inline: true },
                { name: 'Total Push-ups done before today:', value: `**${tamountminus}**`, inline: true },
                { name: 'Total Push-ups done after today:', value: `**${tamount}**`, inline: true },
                )
            .setDescription(`> Today is **${percent}%** through the entire year

*Today is the day **${n}** of the year and **${daysremain}** remain*

**Stats:**`)
            .setFooter({ text: `Created by freewentzy | ${interaction.guild.name}`, iconURL: `${interaction.guild.iconURL()}`});

            await interaction.reply({ embeds: [julembed]})
        }  else if  (interaction.customId == 'aug') {
            const augmodal = new ModalBuilder()
        .setTitle(`Push-up calculator`)
        .setCustomId('augmodal')

        const augday = new TextInputBuilder()
        .setCustomId('day')
        .setRequired(true)
        .setPlaceholder('Ex: 1, 5, 15. . . ')
        .setLabel('The current Day of the Month')
        .setStyle(TextInputStyle.Short);

        const one = new ActionRowBuilder().addComponents(augday);

        augmodal.addComponents(one);
        await interaction.showModal(augmodal);
        } else if (interaction.customId == 'augmodal') {
            const augday = interaction.fields.getTextInputValue('day');            

            const n = Math.floor(parseInt(augday) + 182)
            const sd = Math.floor(n * 86400); // sd = selected date in seconds
            const fulldate = Math.floor(1703998800 + sd);

            const nn = Math.floor(parseInt(n) + 1)
            const m = Math.floor(parseInt(n) * parseInt(nn) )
            const tamount = Math.floor(parseInt(m) / 2)
            const tamountminus = Math.floor(parseInt(tamount)-parseInt(n))

            const percent = Math.round(parseInt(n)/366 * 100)

            const daysremain = Math.round(366-parseInt(n))

            const augembed = new EmbedBuilder()
            .setTitle(`Push-ups for <t:${fulldate}:D>`)
            .addFields(
                { name: 'Push-ups required for the day:', value: `**${n}**`, inline: true },
                { name: 'Total Push-ups done before today:', value: `**${tamountminus}**`, inline: true },
                { name: 'Total Push-ups done after today:', value: `**${tamount}**`, inline: true },
                )
            .setDescription(`> Today is **${percent}%** through the entire year

*Today is the day **${n}** of the year and **${daysremain}** remain*

**Stats:**`)
            .setFooter({ text: `Created by freewentzy | ${interaction.guild.name}`, iconURL: `${interaction.guild.iconURL()}`});

            await interaction.reply({ embeds: [augembed]})
        } else if  (interaction.customId == 'sep') { //////////////////////////////
            const sepmodal = new ModalBuilder()
        .setTitle(`Push-up calculator`)
        .setCustomId('sepmodal')

        const sepday = new TextInputBuilder()
        .setCustomId('day')
        .setRequired(true)
        .setPlaceholder('Ex: 1, 5, 15. . . ')
        .setLabel('The current Day of the Month')
        .setStyle(TextInputStyle.Short);

        const one = new ActionRowBuilder().addComponents(sepday);

        sepmodal.addComponents(one);
        await interaction.showModal(sepmodal);
        } else if (interaction.customId == 'sepmodal') {
            const sepday = interaction.fields.getTextInputValue('day');            

            const n = Math.floor(parseInt(sepday) + 182)
            const sd = Math.floor(n * 86400); // sd = selected date in seconds
            const fulldate = Math.floor(1703998800 + sd);

            const nn = Math.floor(parseInt(n) + 1)
            const m = Math.floor(parseInt(n) * parseInt(nn) )
            const tamount = Math.floor(parseInt(m) / 2)
            const tamountminus = Math.floor(parseInt(tamount)-parseInt(n))

            const percent = Math.round(parseInt(n)/366 * 100)

            const daysremain = Math.round(366-parseInt(n))

            const sepembed = new EmbedBuilder()
            .setTitle(`Push-ups for <t:${fulldate}:D>`)
            .addFields(
                { name: 'Push-ups required for the day:', value: `**${n}**`, inline: true },
                { name: 'Total Push-ups done before today:', value: `**${tamountminus}**`, inline: true },
                { name: 'Total Push-ups done after today:', value: `**${tamount}**`, inline: true },
                )
            .setDescription(`> Today is **${percent}%** through the entire year

*Today is the day **${n}** of the year and **${daysremain}** remain*

**Stats:**`)
            .setFooter({ text: `Created by freewentzy | ${interaction.guild.name}`, iconURL: `${interaction.guild.iconURL()}`});

            await interaction.reply({ embeds: [sepembed]})
        } 
    }
}